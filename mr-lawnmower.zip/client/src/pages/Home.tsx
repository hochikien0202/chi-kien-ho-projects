/* =============================================================
   Home — Mr. Lawnmower Landscaping Services
   Full page assembly: Hero → About → Services → Stats →
   WhyUs → Gallery → Reviews → Contact → Footer
   ============================================================= */

import { useScrollReveal } from "@/hooks/useScrollReveal";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Services from "@/components/Services";
import Stats from "@/components/Stats";
import WhyUs from "@/components/WhyUs";
import Gallery from "@/components/Gallery";
import Reviews from "@/components/Reviews";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";
import FloatingCTA from "@/components/FloatingCTA";
import CTABand from "@/components/CTABand";

export default function Home() {
  useScrollReveal();
  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      <Navbar />
      <Hero />
      <About />
      <Services />
      <Stats />
      <WhyUs />
      <CTABand />
      <Gallery />
      <Reviews />
      <Contact />
      <Footer />
      <FloatingCTA />
    </div>
  );
}
