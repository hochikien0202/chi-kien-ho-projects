/* =============================================================
   Navbar — Corporate Precision design
   Sticky top nav with navy background, green accent, mobile drawer
   ============================================================= */

import { useState, useEffect } from "react";
import { Menu, X, Phone, Leaf } from "lucide-react";

const navLinks = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Why Us", href: "#why-us" },
  { label: "Gallery", href: "#gallery" },
  { label: "Reviews", href: "#reviews" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setMenuOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? "bg-[#0d2137]/98 backdrop-blur-md shadow-lg shadow-black/20"
            : "bg-[#0d2137]"
        }`}
      >
        <div className="container">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <button
              onClick={() => handleNavClick("#home")}
              className="flex items-center gap-2.5 group"
            >
              <div className="w-9 h-9 rounded-lg bg-[#2d7a3a] flex items-center justify-center shadow-md group-hover:bg-[#3a9448] transition-colors">
                <Leaf className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <div className="leading-tight">
                <span className="block font-bold text-white text-base" style={{ fontFamily: "'Sora', sans-serif" }}>
                  Mr. Lawnmower
                </span>
                <span className="block text-[10px] text-[#7eb8d4] tracking-widest uppercase font-medium">
                  Landscaping Services
                </span>
              </div>
            </button>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-7">
              {navLinks.map((link) => (
                <button
                  key={link.href}
                  onClick={() => handleNavClick(link.href)}
                  className="nav-link text-sm font-medium text-slate-300 hover:text-white transition-colors"
                >
                  {link.label}
                </button>
              ))}
            </nav>

            {/* Desktop CTAs */}
            <div className="hidden lg:flex items-center gap-3">
              <a
                href="tel:+14165550123"
                className="flex items-center gap-2 text-sm font-semibold text-[#7eb8d4] hover:text-white transition-colors"
              >
                <Phone className="w-4 h-4" />
                (416) 555-0123
              </a>
              <button
                onClick={() => handleNavClick("#contact")}
                className="px-5 py-2.5 rounded-lg bg-[#2d7a3a] hover:bg-[#3a9448] text-white text-sm font-semibold transition-all duration-200 hover:shadow-lg hover:shadow-green-900/30 active:scale-95"
                style={{ fontFamily: "'Sora', sans-serif" }}
              >
                Request a Quote
              </button>
            </div>

            {/* Mobile menu toggle */}
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="lg:hidden p-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
              aria-label="Toggle menu"
            >
              {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer */}
      <div
        className={`fixed inset-0 z-40 lg:hidden transition-all duration-300 ${
          menuOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
      >
        {/* Backdrop */}
        <div
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          onClick={() => setMenuOpen(false)}
        />
        {/* Drawer */}
        <div
          className={`absolute top-0 right-0 h-full w-72 bg-[#0d2137] shadow-2xl transition-transform duration-300 ${
            menuOpen ? "translate-x-0" : "translate-x-full"
          }`}
        >
          <div className="flex flex-col h-full pt-20 pb-8 px-6">
            <nav className="flex flex-col gap-1 flex-1">
              {navLinks.map((link) => (
                <button
                  key={link.href}
                  onClick={() => handleNavClick(link.href)}
                  className="text-left px-4 py-3 rounded-lg text-slate-200 hover:text-white hover:bg-white/10 font-medium transition-colors"
                >
                  {link.label}
                </button>
              ))}
            </nav>
            <div className="flex flex-col gap-3 pt-6 border-t border-white/10">
              <a
                href="tel:+14165550123"
                className="flex items-center gap-2 px-4 py-3 rounded-lg bg-[#1e6fa8]/20 text-[#7eb8d4] font-semibold hover:bg-[#1e6fa8]/30 transition-colors"
              >
                <Phone className="w-4 h-4" />
                (416) 555-0123
              </a>
              <button
                onClick={() => handleNavClick("#contact")}
                className="px-4 py-3 rounded-lg bg-[#2d7a3a] hover:bg-[#3a9448] text-white font-semibold transition-colors"
                style={{ fontFamily: "'Sora', sans-serif" }}
              >
                Request a Quote
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
