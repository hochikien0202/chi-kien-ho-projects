/* =============================================================
   CTABand — Mid-page conversion band
   Diagonal clip, navy background, bold headline + dual CTAs
   ============================================================= */

import { Phone, ChevronRight } from "lucide-react";

export default function CTABand() {
  const scrollToContact = () => {
    document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      className="py-20 relative overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #0d2137 0%, #142a3d 50%, #0d2137 100%)",
      }}
    >
      {/* Decorative background pattern */}
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}
      />

      <div className="container relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="text-center lg:text-left">
            <h2
              className="text-3xl lg:text-4xl font-extrabold text-white mb-3"
              style={{ fontFamily: "'Sora', sans-serif" }}
            >
              Ready for a Lawn You'll Love?
            </h2>
            <p className="text-slate-400 text-lg max-w-xl">
              Join 500+ satisfied Toronto homeowners. Get your free, no-obligation
              quote today — we respond within 2 hours.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 shrink-0">
            <button
              onClick={scrollToContact}
              className="group flex items-center justify-center gap-2 px-8 py-4 rounded-lg bg-[#2d7a3a] hover:bg-[#3a9448] text-white font-bold text-base transition-all duration-200 hover:shadow-xl hover:shadow-green-900/40 active:scale-95"
              style={{ fontFamily: "'Sora', sans-serif" }}
            >
              Request a Free Quote
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <a
              href="tel:+14165550123"
              className="flex items-center justify-center gap-2 px-8 py-4 rounded-lg border-2 border-white/20 hover:border-white/50 text-white font-bold text-base transition-all duration-200 hover:bg-white/5"
              style={{ fontFamily: "'Sora', sans-serif" }}
            >
              <Phone className="w-5 h-5" />
              (416) 555-0123
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
