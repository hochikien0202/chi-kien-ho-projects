/* =============================================================
   Gallery — Corporate Precision design
   Light grey background, masonry-style grid with hover overlays
   ============================================================= */

import { useEffect, useRef, useState } from "react";
import { X, ZoomIn } from "lucide-react";

const HERO_IMAGE =
  "https://private-us-east-1.manuscdn.com/sessionFile/ugpe1vaCKK9olzvM6bDYUf/sandbox/Ry8KhnkzL96CCQbeN9H8OW-img-1_1771946845000_na1fn_aGVyby1sYXdu.jpg?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvdWdwZTF2YUNLSzlvbHp2TTZiRFlVZi9zYW5kYm94L1J5OEtobmt6TDk2Q0NRYmVOOUg4T1ctaW1nLTFfMTc3MTk0Njg0NTAwMF9uYTFmbl9hR1Z5Ynkxc1lYZHUuanBnP3gtb3NzLXByb2Nlc3M9aW1hZ2UvcmVzaXplLHdfMTkyMCxoXzE5MjAvZm9ybWF0LHdlYnAvcXVhbGl0eSxxXzgwIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=FOV96i-9Q7aqFgk3iIQMW~TwodBO3beoXzHoTU88XspUf1F7ZewLiKso5AkrZH0mSE-76pGYpRcjkapa2qdY5bMeTiJrBbwqPfrZCik90x6xpkvpAYqYb8-RAXwzn5M1pePzpoAcROjnAFJczqlGq43Q10FVzrQjXGQ1QVs3KW0b2O~O0PZhogQ1z3QiwCLUpMucOJ6cZZu2DXTix0Ne5Hs~7sd3JAcm7xcwbw0vYdxq8WOACdzbUxPf1nnwaqdZoQfGMy6Wrw3igmXA1rp9uRN77jO2DhemXSoyyQOZPj~aFeHPdsmJ4V6qjQiccVwqlvMfLvFVxbHL5Sqgxl7QVg__";

const SNOW_IMAGE =
  "https://private-us-east-1.manuscdn.com/sessionFile/ugpe1vaCKK9olzvM6bDYUf/sandbox/Ry8KhnkzL96CCQbeN9H8OW-img-2_1771946848000_na1fn_c25vdy1yZW1vdmFs.jpg?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvdWdwZTF2YUNLSzlvbHp2TTZiRFlVZi9zYW5kYm94L1J5OEtobmt6TDk2Q0NRYmVOOUg4T1ctaW1nLTJfMTc3MTk0Njg0ODAwMF9uYTFmbl9jMjV2ZHkxeVpXMXZkbUZzLmpwZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=QTPBtNROMMmsugULSCfY0PTZbikawRoSyZYKz8vjTY34Da~6ARvJQ01l8OTKjtvILBFPVH2coremCJHt~F4BwlKpgKO7DQ-i~bNjURX0GnBekPTUqqMSOXTV7OESn7FDD1qCglrIEb9lHbQdTSxoe41G~HKWB9aWc6cE8lsAuweBw1k04-W016UuL~bzk2gsSTnlhIpHGnowEbKyt8R0qtMjgUBTBPZtTX0vY-K90o8JqLl~vR2obEdpaQ3PS92j6dV8cJth4oCPs~oGshlMl9lXRY51mYAF1Q7AKd~zFm4c-4jnIuAUgLZsNCeLGUVzyW0kypLCxJfqC1daxNTDYw__";

const IRRIGATION_IMAGE =
  "https://private-us-east-1.manuscdn.com/sessionFile/ugpe1vaCKK9olzvM6bDYUf/sandbox/Ry8KhnkzL96CCQbeN9H8OW-img-3_1771946845000_na1fn_aXJyaWdhdGlvbi1zeXN0ZW0.jpg?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvdWdwZTF2YUNLSzlvbHp2TTZiRFlVZi9zYW5kYm94L1J5OEtobmt6TDk2Q0NRYmVOOUg4T1ctaW1nLTNfMTc3MTk0Njg0NTAwMF9uYTFmbl9hWEp5YVdkaGRHbHZiaTF6ZVhOMFpXMC5qcGc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=ge5rz~pgJmb9~3TzocNlWurbrlYznj99oVDZC~pTbkVWcvX9ZkX5PhvScrOmJ5TESpO89NKg4rqd4ah0LIXUE8QBEmlqFx7opmKCR2nH~0UJQGvZX~U2URGrTpOGDQ2oZc41ahgyYnPAEp9H2gHcaX3sE-J6bF5uej1txOdvyXoQ76JiEJbLuWT7H9mZUO4GudMpVrLuEcaiILQrZSFm69w8zLip3dGBEG~wx76KrNldY47v0jjYuYVdUuNcjxiaYp51QvI-7Y828XpDHb0jaZxHX7V85lad~U37J-HsOeBZRVUBKiNAjYB4Ec9xWOifaApnHRChes3pLoBXShN7~A__";

const SEASONAL_IMAGE =
  "https://private-us-east-1.manuscdn.com/sessionFile/ugpe1vaCKK9olzvM6bDYUf/sandbox/Ry8KhnkzL96CCQbeN9H8OW-img-4_1771946843000_na1fn_c2Vhc29uYWwtY2xlYW51cA.jpg?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvdWdwZTF2YUNLSzlvbHp2TTZiRFlVZi9zYW5kYm94L1J5OEtobmt6TDk2Q0NRYmVOOUg4T1ctaW1nLTRfMTc3MTk0Njg0MzAwMF9uYTFmbl9jMlZoYzI5dVlXd3RZMnhsWVc1MWNBLmpwZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=bXrJ80Nyt~2xGhPMrs8BKBRazC-y9BUQhn6opCwKqk~v2X6q1U0fixZ4mEqRL8IabiqcqQh9d1a2VBHLuUAtyM4Pob~kjwv-UAtKL3qt6kdprNXLPzlkg-oMChhUZpf-yjV~EAKlK-39RAwN-zzw29uMzywA37VgJQaK6bPdrT11VArC9cmmJqaaG2YmvTOLFiLodc1Nh8I1AutI8C5vJGl6MYGhWFFK3m4ToiVAAAd-lO1FnBmCNIOEwDiBg31IL9FN5ylqh9MmM5Li5vYGOysXKiEjxg7XR1Vklh7NkwRi9rcI6DMT2eCtVVXOd6BzmqboFiQeSr23O6T38Ds7AA__";

const galleryItems = [
  {
    src: HERO_IMAGE,
    label: "Residential Lawn Maintenance",
    span: "lg:col-span-2 lg:row-span-2",
    height: "h-72 lg:h-full",
  },
  {
    src: SNOW_IMAGE,
    label: "Snow & Ice Management",
    span: "",
    height: "h-52",
  },
  {
    src: IRRIGATION_IMAGE,
    label: "Irrigation System Install",
    span: "",
    height: "h-52",
  },
  {
    src: SEASONAL_IMAGE,
    label: "Fall Seasonal Cleanup",
    span: "lg:col-span-2",
    height: "h-64",
  },
  {
    src: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800&q=80",
    label: "Garden Bed Design",
    span: "",
    height: "h-64",
  },
  {
    src: "https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=800&q=80",
    label: "Hedge Trimming & Edging",
    span: "",
    height: "h-64",
  },
];

export default function Gallery() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [lightbox, setLightbox] = useState<string | null>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll(".reveal").forEach((el, i) => {
              setTimeout(() => el.classList.add("visible"), i * 80);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setLightbox(null);
    };
    if (lightbox) window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [lightbox]);

  return (
    <section id="gallery" className="py-24 bg-white" ref={sectionRef}>
      <div className="container">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="reveal inline-flex items-center gap-3 mb-4">
            <div className="h-px w-10 bg-[#2d7a3a]" />
            <span className="text-[#2d7a3a] text-sm font-semibold tracking-wider uppercase">
              Our Work
            </span>
            <div className="h-px w-10 bg-[#2d7a3a]" />
          </div>
          <h2
            className="reveal text-4xl lg:text-5xl font-extrabold text-[#0d2137] leading-tight mb-4"
            style={{ fontFamily: "'Sora', sans-serif" }}
          >
            Results That Speak for Themselves
          </h2>
          <p className="reveal text-slate-500 text-lg max-w-xl mx-auto">
            Browse a selection of recent projects across Toronto and the GTA.
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 lg:grid-rows-2 gap-4 lg:h-[600px]">
          {galleryItems.map((item, i) => (
            <div
              key={item.label}
              className={`reveal reveal-delay-${Math.min(i, 4)} ${item.span} relative overflow-hidden rounded-2xl group cursor-pointer ${item.height}`}
              onClick={() => setLightbox(item.src)}
            >
              <img
                src={item.src}
                alt={item.label}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0d2137]/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-4 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-300">
                <span className="text-white font-semibold text-sm">{item.label}</span>
              </div>
              <div className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <ZoomIn className="w-4 h-4 text-white" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightbox && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
          onClick={() => setLightbox(null)}
        >
          <button
            className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors"
            onClick={() => setLightbox(null)}
          >
            <X className="w-5 h-5" />
          </button>
          <img
            src={lightbox}
            alt="Gallery preview"
            className="max-w-full max-h-[85vh] rounded-xl object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </section>
  );
}
