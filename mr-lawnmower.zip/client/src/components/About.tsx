/* =============================================================
   About — Corporate Precision design
   Asymmetric two-column: large image left, editorial text right
   Navy accent bar, highlight pills, team photo
   ============================================================= */

import { useEffect, useRef } from "react";
import { CheckCircle2, MapPin, Calendar } from "lucide-react";

const ABOUT_IMAGE =
  "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80";

const highlights = [
  "Family-owned and operated since 2008",
  "Fully licensed, bonded & insured in Ontario",
  "Certified landscape professionals on every crew",
  "Eco-friendly practices and responsible disposal",
  "Year-round service — spring through winter",
  "Dedicated account manager for every client",
];

export default function About() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll(".reveal").forEach((el, i) => {
              setTimeout(() => el.classList.add("visible"), i * 100);
            });
          }
        });
      },
      { threshold: 0.15 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="about" className="py-24 bg-white" ref={sectionRef}>
      <div className="container">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image column */}
          <div className="reveal relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-navy/20">
              <img
                src={ABOUT_IMAGE}
                alt="Mr. Lawnmower landscaping team at work"
                className="w-full h-[480px] object-cover"
                loading="lazy"
              />
              {/* Overlay badge */}
              <div className="absolute bottom-6 left-6 bg-[#0d2137] rounded-xl px-5 py-4 shadow-xl">
                <div className="flex items-center gap-3">
                  <Calendar className="w-8 h-8 text-[#4ade80]" />
                  <div>
                    <div className="text-2xl font-extrabold text-white" style={{ fontFamily: "'Sora', sans-serif" }}>
                      15+
                    </div>
                    <div className="text-xs text-slate-400 font-medium">Years of Excellence</div>
                  </div>
                </div>
              </div>
            </div>
            {/* Decorative accent */}
            <div className="absolute -top-4 -left-4 w-24 h-24 rounded-2xl bg-[#2d7a3a]/15 -z-10" />
            <div className="absolute -bottom-4 -right-4 w-32 h-32 rounded-2xl bg-[#1e6fa8]/10 -z-10" />
          </div>

          {/* Text column */}
          <div>
            <div className="reveal flex items-center gap-3 mb-4">
              <div className="h-1 w-10 rounded-full bg-[#2d7a3a]" />
              <span className="text-[#2d7a3a] text-sm font-semibold tracking-wider uppercase">
                About Us
              </span>
            </div>

            <h2
              className="reveal text-4xl lg:text-5xl font-extrabold text-[#0d2137] leading-tight mb-6"
              style={{ fontFamily: "'Sora', sans-serif" }}
            >
              Toronto's Trusted
              <br />
              Landscaping Partner
            </h2>

            <p className="reveal text-slate-600 leading-relaxed mb-4">
              Mr. Lawnmower Landscaping Services was founded in 2008 with a simple
              mission: deliver exceptional outdoor spaces with the reliability and
              professionalism that Toronto homeowners and businesses deserve.
            </p>
            <p className="reveal text-slate-600 leading-relaxed mb-8">
              From our base in Toronto, we serve the Greater Toronto Area with a
              full suite of landscaping services — from weekly lawn maintenance to
              complex irrigation installations and 24/7 winter snow management. Our
              certified crews treat every property as if it were their own.
            </p>

            {/* Highlights grid */}
            <div className="reveal grid sm:grid-cols-2 gap-3 mb-8">
              {highlights.map((item) => (
                <div key={item} className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-5 h-5 text-[#2d7a3a] mt-0.5 shrink-0" />
                  <span className="text-sm text-slate-700 font-medium">{item}</span>
                </div>
              ))}
            </div>

            {/* Location pill */}
            <div className="reveal flex items-center gap-2 px-4 py-3 rounded-lg bg-[#f0f7f2] border border-[#2d7a3a]/20 w-fit">
              <MapPin className="w-4 h-4 text-[#2d7a3a]" />
              <span className="text-sm font-semibold text-[#0d2137]">
                Proudly serving Toronto & the GTA
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
