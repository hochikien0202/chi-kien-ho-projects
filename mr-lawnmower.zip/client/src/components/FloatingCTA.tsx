/* =============================================================
   FloatingCTA — Mobile sticky bottom bar
   Appears after scrolling past hero, two action buttons
   ============================================================= */

import { useEffect, useState } from "react";
import { Phone, ChevronRight } from "lucide-react";

export default function FloatingCTA() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 500);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollToContact = () => {
    document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div
      className={`fixed bottom-0 left-0 right-0 z-40 lg:hidden transition-transform duration-300 ${
        visible ? "translate-y-0" : "translate-y-full"
      }`}
    >
      <div className="bg-[#0d2137] border-t border-white/10 px-4 py-3 flex gap-3">
        <a
          href="tel:+14165550123"
          className="flex-1 flex items-center justify-center gap-2 py-3 rounded-lg bg-[#1e6fa8] text-white font-semibold text-sm"
        >
          <Phone className="w-4 h-4" />
          Call Now
        </a>
        <button
          onClick={scrollToContact}
          className="flex-1 flex items-center justify-center gap-2 py-3 rounded-lg bg-[#2d7a3a] text-white font-semibold text-sm"
          style={{ fontFamily: "'Sora', sans-serif" }}
        >
          Get a Quote
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
