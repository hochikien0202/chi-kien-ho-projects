/* =============================================================
   Footer — Corporate Precision design
   Deep navy, 4-column layout, green accent, sitemap links
   ============================================================= */

import { Leaf, Phone, Mail, MapPin, Facebook, Instagram, Linkedin } from "lucide-react";

const serviceLinks = [
  "Landscape Maintenance",
  "Snow & Ice Management",
  "Irrigation Systems",
  "Seasonal Cleanups",
  "Landscape Design",
  "Commercial Services",
];

const quickLinks = [
  { label: "About Us", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Why Choose Us", href: "#why-us" },
  { label: "Gallery", href: "#gallery" },
  { label: "Reviews", href: "#reviews" },
  { label: "Contact", href: "#contact" },
];

export default function Footer() {
  const scrollTo = (href: string) => {
    document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer className="bg-[#071520] border-t border-white/5">
      <div className="container py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand column */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-9 h-9 rounded-lg bg-[#2d7a3a] flex items-center justify-center">
                <Leaf className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <div>
                <div className="font-bold text-white text-base" style={{ fontFamily: "'Sora', sans-serif" }}>
                  Mr. Lawnmower
                </div>
                <div className="text-[10px] text-[#7eb8d4] tracking-widest uppercase font-medium">
                  Landscaping Services
                </div>
              </div>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed mb-5">
              Toronto's trusted landscaping partner since 2008. Professional,
              reliable, and committed to excellence every season.
            </p>
            <div className="flex gap-3">
              {[
                { Icon: Facebook, href: "#" },
                { Icon: Instagram, href: "#" },
                { Icon: Linkedin, href: "#" },
              ].map(({ Icon, href }, i) => (
                <a
                  key={i}
                  href={href}
                  className="w-9 h-9 rounded-lg bg-white/5 hover:bg-[#2d7a3a]/30 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <h4
              className="text-white font-semibold text-sm mb-4 uppercase tracking-wider"
              style={{ fontFamily: "'Sora', sans-serif" }}
            >
              Services
            </h4>
            <ul className="space-y-2.5">
              {serviceLinks.map((s) => (
                <li key={s}>
                  <button
                    onClick={() => scrollTo("#services")}
                    className="text-slate-400 hover:text-[#4ade80] text-sm transition-colors text-left"
                  >
                    {s}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick links */}
          <div>
            <h4
              className="text-white font-semibold text-sm mb-4 uppercase tracking-wider"
              style={{ fontFamily: "'Sora', sans-serif" }}
            >
              Quick Links
            </h4>
            <ul className="space-y-2.5">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <button
                    onClick={() => scrollTo(link.href)}
                    className="text-slate-400 hover:text-[#4ade80] text-sm transition-colors text-left"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4
              className="text-white font-semibold text-sm mb-4 uppercase tracking-wider"
              style={{ fontFamily: "'Sora', sans-serif" }}
            >
              Contact Us
            </h4>
            <ul className="space-y-4">
              <li>
                <a
                  href="tel:+14165550123"
                  className="flex items-center gap-3 text-slate-400 hover:text-white transition-colors group"
                >
                  <Phone className="w-4 h-4 text-[#2d7a3a] shrink-0" />
                  <span className="text-sm">(416) 555-0123</span>
                </a>
              </li>
              <li>
                <a
                  href="mailto:info@mrlawnmower.ca"
                  className="flex items-center gap-3 text-slate-400 hover:text-white transition-colors"
                >
                  <Mail className="w-4 h-4 text-[#2d7a3a] shrink-0" />
                  <span className="text-sm">info@mrlawnmower.ca</span>
                </a>
              </li>
              <li className="flex items-start gap-3 text-slate-400">
                <MapPin className="w-4 h-4 text-[#2d7a3a] shrink-0 mt-0.5" />
                <span className="text-sm">Toronto & Greater Toronto Area, Ontario</span>
              </li>
            </ul>

            {/* CTA */}
            <button
              onClick={() => scrollTo("#contact")}
              className="mt-6 w-full px-4 py-3 rounded-lg bg-[#2d7a3a] hover:bg-[#3a9448] text-white font-semibold text-sm transition-colors"
              style={{ fontFamily: "'Sora', sans-serif" }}
            >
              Request a Free Quote
            </button>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/5">
        <div className="container py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-slate-500 text-xs">
            © {new Date().getFullYear()} Mr. Lawnmower Landscaping Services. All rights reserved.
          </p>
          <div className="flex gap-5">
            <span className="text-slate-500 text-xs hover:text-slate-300 cursor-pointer transition-colors">
              Privacy Policy
            </span>
            <span className="text-slate-500 text-xs hover:text-slate-300 cursor-pointer transition-colors">
              Terms of Service
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
