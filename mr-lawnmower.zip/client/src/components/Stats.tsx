/* =============================================================
   Stats — Corporate Precision design
   Green band with large animated counter numerals
   ============================================================= */

import { useEffect, useRef, useState } from "react";

const stats = [
  { value: 500, suffix: "+", label: "Happy Clients", sublabel: "Across the GTA" },
  { value: 15, suffix: "+", label: "Years in Business", sublabel: "Since 2008" },
  { value: 96, suffix: "%", label: "Client Retention", sublabel: "Year over year" },
  { value: 24, suffix: "/7", label: "Snow Response", sublabel: "Winter availability" },
];

function Counter({ target, suffix, active }: { target: number; suffix: string; active: boolean }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!active) return;
    const duration = 1800;
    const steps = 60;
    const increment = target / steps;
    let current = 0;
    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);
    return () => clearInterval(timer);
  }, [active, target]);

  return (
    <span>
      {count}
      {suffix}
    </span>
  );
}

export default function Stats() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setActive(true);
          // Trigger reveal animations
          entries[0].target.querySelectorAll(".reveal").forEach((el, i) => {
            setTimeout(() => el.classList.add("visible"), i * 100);
          });
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section className="py-16 bg-[#2d7a3a]" ref={sectionRef}>
      <div className="container">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-4">
          {stats.map((stat, i) => (
            <div
              key={stat.label}
              className={`text-center reveal${i > 0 ? ` reveal-delay-${i}` : ""}`}
            >
              <div
                className="text-5xl lg:text-6xl font-extrabold text-white mb-1 tabular-nums"
                style={{ fontFamily: "'Sora', sans-serif" }}
              >
                <Counter target={stat.value} suffix={stat.suffix} active={active} />
              </div>
              <div className="text-lg font-semibold text-white/90 mb-0.5">
                {stat.label}
              </div>
              <div className="text-sm text-white/60">{stat.sublabel}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
