/* =============================================================
   Services — Corporate Precision design
   Navy background section, 4-card grid with image thumbnails,
   numbered cards, diagonal clip top
   ============================================================= */

import { useEffect, useRef } from "react";
import { Scissors, Snowflake, Droplets, Leaf, ChevronRight } from "lucide-react";

const SNOW_IMAGE =
  "https://private-us-east-1.manuscdn.com/sessionFile/ugpe1vaCKK9olzvM6bDYUf/sandbox/Ry8KhnkzL96CCQbeN9H8OW-img-2_1771946848000_na1fn_c25vdy1yZW1vdmFs.jpg?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvdWdwZTF2YUNLSzlvbHp2TTZiRFlVZi9zYW5kYm94L1J5OEtobmt6TDk2Q0NRYmVOOUg4T1ctaW1nLTJfMTc3MTk0Njg0ODAwMF9uYTFmbl9jMjV2ZHkxeVpXMXZkbUZzLmpwZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=QTPBtNROMMmsugULSCfY0PTZbikawRoSyZYKz8vjTY34Da~6ARvJQ01l8OTKjtvILBFPVH2coremCJHt~F4BwlKpgKO7DQ-i~bNjURX0GnBekPTUqqMSOXTV7OESn7FDD1qCglrIEb9lHbQdTSxoe41G~HKWB9aWc6cE8lsAuweBw1k04-W016UuL~bzk2gsSTnlhIpHGnowEbKyt8R0qtMjgUBTBPZtTX0vY-K90o8JqLl~vR2obEdpaQ3PS92j6dV8cJth4oCPs~oGshlMl9lXRY51mYAF1Q7AKd~zFm4c-4jnIuAUgLZsNCeLGUVzyW0kypLCxJfqC1daxNTDYw__";

const IRRIGATION_IMAGE =
  "https://private-us-east-1.manuscdn.com/sessionFile/ugpe1vaCKK9olzvM6bDYUf/sandbox/Ry8KhnkzL96CCQbeN9H8OW-img-3_1771946845000_na1fn_aXJyaWdhdGlvbi1zeXN0ZW0.jpg?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvdWdwZTF2YUNLSzlvbHp2TTZiRFlVZi9zYW5kYm94L1J5OEtobmt6TDk2Q0NRYmVOOUg4T1ctaW1nLTNfMTc3MTk0Njg0NTAwMF9uYTFmbl9hWEp5YVdkaGRHbHZiaTF6ZVhOMFpXMC5qcGc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=ge5rz~pgJmb9~3TzocNlWurbrlYznj99oVDZC~pTbkVWcvX9ZkX5PhvScrOmJ5TESpO89NKg4rqd4ah0LIXUE8QBEmlqFx7opmKCR2nH~0UJQGvZX~U2URGrTpOGDQ2oZc41ahgyYnPAEp9H2gHcaX3sE-J6bF5uej1txOdvyXoQ76JiEJbLuWT7H9mZUO4GudMpVrLuEcaiILQrZSFm69w8zLip3dGBEG~wx76KrNldY47v0jjYuYVdUuNcjxiaYp51QvI-7Y828XpDHb0jaZxHX7V85lad~U37J-HsOeBZRVUBKiNAjYB4Ec9xWOifaApnHRChes3pLoBXShN7~A__";

const SEASONAL_IMAGE =
  "https://private-us-east-1.manuscdn.com/sessionFile/ugpe1vaCKK9olzvM6bDYUf/sandbox/Ry8KhnkzL96CCQbeN9H8OW-img-4_1771946843000_na1fn_c2Vhc29uYWwtY2xlYW51cA.jpg?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvdWdwZTF2YUNLSzlvbHp2TTZiRFlVZi9zYW5kYm94L1J5OEtobmt6TDk2Q0NRYmVOOUg4T1ctaW1nLTRfMTc3MTk0Njg0MzAwMF9uYTFmbl9jMlZoYzI5dVlXd3RZMnhsWVc1MWNBLmpwZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=bXrJ80Nyt~2xGhPMrs8BKBRazC-y9BUQhn6opCwKqk~v2X6q1U0fixZ4mEqRL8IabiqcqQh9d1a2VBHLuUAtyM4Pob~kjwv-UAtKL3qt6kdprNXLPzlkg-oMChhUZpf-yjV~EAKlK-39RAwN-zzw29uMzywA37VgJQaK6bPdrT11VArC9cmmJqaaG2YmvTOLFiLodc1Nh8I1AutI8C5vJGl6MYGhWFFK3m4ToiVAAAd-lO1FnBmCNIOEwDiBg31IL9FN5ylqh9MmM5Li5vYGOysXKiEjxg7XR1Vklh7NkwRi9rcI6DMT2eCtVVXOd6BzmqboFiQeSr23O6T38Ds7AA__";

const MAINTENANCE_IMAGE =
  "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800&q=80";

const services = [
  {
    number: "01",
    icon: Scissors,
    title: "Landscape Maintenance",
    description:
      "Weekly and bi-weekly lawn mowing, edging, trimming, fertilization, weed control, and garden bed maintenance to keep your property looking immaculate year-round.",
    features: ["Lawn mowing & edging", "Fertilization programs", "Weed & pest control", "Garden bed care"],
    image: MAINTENANCE_IMAGE,
    color: "#2d7a3a",
  },
  {
    number: "02",
    icon: Snowflake,
    title: "Snow & Ice Management",
    description:
      "24/7 on-call snow plowing, salting, and ice management for driveways, walkways, and commercial properties. We respond before you wake up.",
    features: ["24/7 emergency response", "Driveway & walkway clearing", "De-icing & salting", "Commercial contracts"],
    image: SNOW_IMAGE,
    color: "#1e6fa8",
  },
  {
    number: "03",
    icon: Droplets,
    title: "Irrigation Systems",
    description:
      "Design, installation, and seasonal maintenance of smart irrigation systems that conserve water while keeping your lawn and gardens perfectly hydrated.",
    features: ["Custom system design", "Smart controller setup", "Spring startup & winterization", "Leak detection & repair"],
    image: IRRIGATION_IMAGE,
    color: "#2d7a3a",
  },
  {
    number: "04",
    icon: Leaf,
    title: "Seasonal Cleanups",
    description:
      "Comprehensive spring and fall cleanup services including leaf removal, debris clearing, garden bed preparation, and mulching to protect your landscape.",
    features: ["Spring & fall cleanups", "Leaf & debris removal", "Mulching & bed prep", "Pruning & trimming"],
    image: SEASONAL_IMAGE,
    color: "#1e6fa8",
  },
];

export default function Services() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll(".reveal").forEach((el, i) => {
              setTimeout(() => el.classList.add("visible"), i * 120);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const scrollToContact = () => {
    document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="services"
      className="py-24 bg-[#0d2137] clip-diagonal-top"
      ref={sectionRef}
    >
      <div className="container">
        {/* Section header */}
        <div className="text-center mb-16">
          <div className="reveal inline-flex items-center gap-3 mb-4">
            <div className="h-px w-10 bg-[#2d7a3a]" />
            <span className="text-[#4ade80] text-sm font-semibold tracking-wider uppercase">
              Our Services
            </span>
            <div className="h-px w-10 bg-[#2d7a3a]" />
          </div>
          <h2
            className="reveal text-4xl lg:text-5xl font-extrabold text-white leading-tight mb-4"
            style={{ fontFamily: "'Sora', sans-serif" }}
          >
            Complete Landscaping Solutions
          </h2>
          <p className="reveal text-slate-400 text-lg max-w-2xl mx-auto">
            From spring blooms to winter storms, we handle every aspect of your
            outdoor space with expert care and professional equipment.
          </p>
        </div>

        {/* Services grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <div
                key={service.number}
                className="reveal card-lift group rounded-2xl overflow-hidden bg-[#142a3d] border border-white/5 hover:border-white/15 transition-all duration-300"
              >
                {/* Image */}
                <div className="relative h-52 overflow-hidden">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#142a3d] via-transparent to-transparent" />
                  {/* Number badge */}
                  <div
                    className="absolute top-4 left-4 w-10 h-10 rounded-lg flex items-center justify-center text-white font-extrabold text-sm"
                    style={{ backgroundColor: service.color, fontFamily: "'Sora', sans-serif" }}
                  >
                    {service.number}
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <div
                      className="w-9 h-9 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: `${service.color}25` }}
                    >
                      <Icon className="w-5 h-5" style={{ color: service.color === "#2d7a3a" ? "#4ade80" : "#7eb8d4" }} />
                    </div>
                    <h3
                      className="text-xl font-bold text-white"
                      style={{ fontFamily: "'Sora', sans-serif" }}
                    >
                      {service.title}
                    </h3>
                  </div>
                  <p className="text-slate-400 text-sm leading-relaxed mb-4">
                    {service.description}
                  </p>
                  <ul className="grid grid-cols-2 gap-1.5 mb-5">
                    {service.features.map((feat) => (
                      <li key={feat} className="flex items-center gap-1.5 text-xs text-slate-300">
                        <span
                          className="w-1.5 h-1.5 rounded-full shrink-0"
                          style={{ backgroundColor: service.color === "#2d7a3a" ? "#4ade80" : "#7eb8d4" }}
                        />
                        {feat}
                      </li>
                    ))}
                  </ul>
                  <button
                    onClick={scrollToContact}
                    className="flex items-center gap-1.5 text-sm font-semibold transition-colors group/btn"
                    style={{ color: service.color === "#2d7a3a" ? "#4ade80" : "#7eb8d4" }}
                  >
                    Get a Quote
                    <ChevronRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
