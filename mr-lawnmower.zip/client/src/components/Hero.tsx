/* =============================================================
   Hero — Corporate Precision design
   Full-bleed lawn image, dark navy overlay, bold headline,
   dual CTAs, trust badges row, diagonal bottom clip
   ============================================================= */

import { Phone, ChevronRight, Star, Award, Users } from "lucide-react";
import { useEffect, useRef } from "react";

const HERO_IMAGE =
  "https://private-us-east-1.manuscdn.com/sessionFile/ugpe1vaCKK9olzvM6bDYUf/sandbox/Ry8KhnkzL96CCQbeN9H8OW-img-1_1771946845000_na1fn_aGVyby1sYXdu.jpg?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvdWdwZTF2YUNLSzlvbHp2TTZiRFlVZi9zYW5kYm94L1J5OEtobmt6TDk2Q0NRYmVOOUg4T1ctaW1nLTFfMTc3MTk0Njg0NTAwMF9uYTFmbl9hR1Z5Ynkxc1lYZHUuanBnP3gtb3NzLXByb2Nlc3M9aW1hZ2UvcmVzaXplLHdfMTkyMCxoXzE5MjAvZm9ybWF0LHdlYnAvcXVhbGl0eSxxXzgwIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=FOV96i-9Q7aqFgk3iIQMW~TwodBO3beoXzHoTU88XspUf1F7ZewLiKso5AkrZH0mSE-76pGYpRcjkapa2qdY5bMeTiJrBbwqPfrZCik90x6xpkvpAYqYb8-RAXwzn5M1pePzpoAcROjnAFJczqlGq43Q10FVzrQjXGQ1QVs3KW0b2O~O0PZhogQ1z3QiwCLUpMucOJ6cZZu2DXTix0Ne5Hs~7sd3JAcm7xcwbw0vYdxq8WOACdzbUxPf1nnwaqdZoQfGMy6Wrw3igmXA1rp9uRN77jO2DhemXSoyyQOZPj~aFeHPdsmJ4V6qjQiccVwqlvMfLvFVxbHL5Sqgxl7QVg__";

export default function Hero() {
  const headlineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = headlineRef.current;
    if (!el) return;
    const timer = setTimeout(() => el.classList.add("visible"), 100);
    return () => clearTimeout(timer);
  }, []);

  const scrollToContact = () => {
    document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center clip-diagonal-bottom overflow-hidden"
      style={{ paddingTop: "5rem" }}
    >
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${HERO_IMAGE})` }}
      />
      {/* Layered overlay: navy gradient left, dark overall */}
      <div className="absolute inset-0 bg-gradient-to-r from-[#0d2137]/95 via-[#0d2137]/80 to-[#0d2137]/40" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#0d2137]/60 via-transparent to-transparent" />

      <div className="container relative z-10">
        <div className="max-w-2xl">
          {/* Pre-headline badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#2d7a3a]/30 border border-[#2d7a3a]/50 mb-6">
            <span className="w-2 h-2 rounded-full bg-[#4ade80] animate-pulse" />
            <span className="text-[#4ade80] text-xs font-semibold tracking-wider uppercase">
              Toronto's #1 Landscaping Company
            </span>
          </div>

          {/* Headline */}
          <div ref={headlineRef} className="reveal">
            <h1
              className="text-5xl lg:text-6xl xl:text-7xl font-extrabold text-white leading-[1.05] mb-6"
              style={{ fontFamily: "'Sora', sans-serif" }}
            >
              Your Lawn,{" "}
              <span className="text-[#4ade80]">Perfected</span>
              <br />
              Every Season.
            </h1>
            <p className="text-lg text-slate-300 leading-relaxed mb-8 max-w-lg">
              Professional landscaping, snow removal, irrigation, and seasonal
              cleanups for Toronto homeowners and businesses. Reliable, insured,
              and trusted by 500+ clients since 2008.
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-wrap gap-4 mb-12">
            <button
              onClick={scrollToContact}
              className="group flex items-center gap-2 px-7 py-4 rounded-lg bg-[#2d7a3a] hover:bg-[#3a9448] text-white font-bold text-base transition-all duration-200 hover:shadow-xl hover:shadow-green-900/40 active:scale-95"
              style={{ fontFamily: "'Sora', sans-serif" }}
            >
              Request a Free Quote
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <a
              href="tel:+14165550123"
              className="flex items-center gap-2 px-7 py-4 rounded-lg border-2 border-white/30 hover:border-white/60 text-white font-bold text-base transition-all duration-200 hover:bg-white/10 active:scale-95"
              style={{ fontFamily: "'Sora', sans-serif" }}
            >
              <Phone className="w-5 h-5" />
              Call Now
            </a>
          </div>

          {/* Trust badges */}
          <div className="flex flex-wrap gap-6">
            <div className="flex items-center gap-2">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <span className="text-slate-300 text-sm font-medium">4.9/5 on Google</span>
            </div>
            <div className="flex items-center gap-2">
              <Award className="w-4 h-4 text-[#7eb8d4]" />
              <span className="text-slate-300 text-sm font-medium">Licensed & Insured</span>
            </div>
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-[#7eb8d4]" />
              <span className="text-slate-300 text-sm font-medium">500+ Happy Clients</span>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-16 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
        <div className="w-6 h-10 rounded-full border-2 border-white/30 flex items-start justify-center pt-2">
          <div className="w-1.5 h-2.5 rounded-full bg-white/60 animate-pulse" />
        </div>
      </div>
    </section>
  );
}
