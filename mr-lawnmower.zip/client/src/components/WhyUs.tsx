/* =============================================================
   Why Choose Us — Corporate Precision design
   White background, icon cards in asymmetric grid,
   trust badge row at bottom
   ============================================================= */

import { useEffect, useRef } from "react";
import {
  Shield,
  Clock,
  ThumbsUp,
  Wrench,
  Leaf,
  HeadphonesIcon,
  Award,
  BadgeCheck,
} from "lucide-react";

const reasons = [
  {
    icon: Shield,
    title: "Fully Licensed & Insured",
    description:
      "Every crew member is background-checked, and we carry $5M in liability insurance. Your property is always protected.",
    color: "#2d7a3a",
  },
  {
    icon: Clock,
    title: "Always On Time",
    description:
      "We show up when we say we will. Our scheduling system sends you reminders and real-time arrival notifications.",
    color: "#1e6fa8",
  },
  {
    icon: ThumbsUp,
    title: "Satisfaction Guaranteed",
    description:
      "Not happy with the results? We'll come back and make it right — at no extra charge. Your satisfaction is our standard.",
    color: "#2d7a3a",
  },
  {
    icon: Wrench,
    title: "Professional Equipment",
    description:
      "We invest in commercial-grade equipment and maintain it rigorously, so every job is completed to the highest standard.",
    color: "#1e6fa8",
  },
  {
    icon: Leaf,
    title: "Eco-Friendly Practices",
    description:
      "We use organic fertilizers, responsible disposal, and water-smart irrigation to minimize our environmental footprint.",
    color: "#2d7a3a",
  },
  {
    icon: HeadphonesIcon,
    title: "Dedicated Support",
    description:
      "Every client gets a dedicated account manager. One call or text and we handle everything — no runaround.",
    color: "#1e6fa8",
  },
];

const trustBadges = [
  { icon: Award, label: "Landscape Ontario Member" },
  { icon: BadgeCheck, label: "WSIB Certified" },
  { icon: Shield, label: "$5M Liability Insurance" },
  { icon: BadgeCheck, label: "BBB Accredited" },
];

export default function WhyUs() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll(".reveal").forEach((el, i) => {
              setTimeout(() => el.classList.add("visible"), i * 100);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="why-us" className="py-24 bg-[#f8fafb]" ref={sectionRef}>
      <div className="container">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="reveal inline-flex items-center gap-3 mb-4">
            <div className="h-px w-10 bg-[#2d7a3a]" />
            <span className="text-[#2d7a3a] text-sm font-semibold tracking-wider uppercase">
              Why Choose Us
            </span>
            <div className="h-px w-10 bg-[#2d7a3a]" />
          </div>
          <h2
            className="reveal text-4xl lg:text-5xl font-extrabold text-[#0d2137] leading-tight mb-4"
            style={{ fontFamily: "'Sora', sans-serif" }}
          >
            The Mr. Lawnmower Difference
          </h2>
          <p className="reveal text-slate-500 text-lg max-w-2xl mx-auto">
            We don't just maintain lawns — we build long-term relationships with
            homeowners and businesses who expect the best.
          </p>
        </div>

        {/* Reasons grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {reasons.map((reason, i) => {
            const Icon = reason.icon;
            return (
              <div
                key={reason.title}
                className={`reveal reveal-delay-${Math.min(i, 4)} card-lift bg-white rounded-2xl p-6 border border-slate-100 shadow-sm`}
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                  style={{ backgroundColor: `${reason.color}15` }}
                >
                  <Icon className="w-6 h-6" style={{ color: reason.color }} />
                </div>
                <h3
                  className="text-lg font-bold text-[#0d2137] mb-2"
                  style={{ fontFamily: "'Sora', sans-serif" }}
                >
                  {reason.title}
                </h3>
                <p className="text-slate-500 text-sm leading-relaxed">
                  {reason.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Trust badges */}
        <div className="reveal bg-[#0d2137] rounded-2xl px-8 py-6">
          <div className="flex flex-wrap justify-center gap-8 lg:gap-16">
            {trustBadges.map((badge) => {
              const Icon = badge.icon;
              return (
                <div key={badge.label} className="flex items-center gap-3">
                  <Icon className="w-5 h-5 text-[#4ade80]" />
                  <span className="text-white font-semibold text-sm">{badge.label}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
