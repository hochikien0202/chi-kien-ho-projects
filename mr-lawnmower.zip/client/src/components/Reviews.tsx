/* =============================================================
   Reviews — Corporate Precision design
   Navy background, horizontal scroll carousel of testimonial cards,
   Google review badge, overall rating display
   ============================================================= */

import { useEffect, useRef, useState } from "react";
import { Star, ChevronLeft, ChevronRight, Quote } from "lucide-react";

const reviews = [
  {
    name: "Sarah M.",
    location: "North York, Toronto",
    rating: 5,
    date: "October 2024",
    text: "Mr. Lawnmower has been maintaining our property for 3 years now. The crew is always professional, punctual, and the lawn looks absolutely incredible. Our neighbours constantly ask who does our landscaping!",
    service: "Landscape Maintenance",
    avatar: "SM",
  },
  {
    name: "David K.",
    location: "Scarborough, Toronto",
    rating: 5,
    date: "February 2024",
    text: "Best snow removal service in Toronto, hands down. They cleared my driveway before I even woke up during the big February storm. Reliable, thorough, and the pricing is very fair for the quality.",
    service: "Snow & Ice Management",
    avatar: "DK",
  },
  {
    name: "Jennifer L.",
    location: "Etobicoke, Toronto",
    rating: 5,
    date: "June 2024",
    text: "Had them install a new irrigation system last spring. The team was knowledgeable, clean, and completed the job on schedule. My water bill actually went down 20% and the lawn has never looked better.",
    service: "Irrigation Systems",
    avatar: "JL",
  },
  {
    name: "Michael R.",
    location: "Mississauga",
    rating: 5,
    date: "November 2024",
    text: "The fall cleanup crew was exceptional. They removed every leaf, cleaned out the garden beds, and even did some extra pruning I hadn't asked for. True professionals who take pride in their work.",
    service: "Seasonal Cleanup",
    avatar: "MR",
  },
  {
    name: "Patricia W.",
    location: "Markham",
    rating: 5,
    date: "August 2024",
    text: "I've tried 4 different landscaping companies over the years. Mr. Lawnmower is the only one I've stuck with for more than a season. Communication is excellent and the quality is consistent every single visit.",
    service: "Landscape Maintenance",
    avatar: "PW",
  },
  {
    name: "Robert T.",
    location: "Richmond Hill",
    rating: 5,
    date: "March 2024",
    text: "Commercial property owner here. Mr. Lawnmower handles all 3 of my properties. Invoicing is clean, the work is always done right, and they're incredibly responsive when I need something extra. Highly recommend.",
    service: "Commercial Services",
    avatar: "RT",
  },
];

const avatarColors = [
  "bg-[#2d7a3a]",
  "bg-[#1e6fa8]",
  "bg-[#2d7a3a]",
  "bg-[#1e6fa8]",
  "bg-[#2d7a3a]",
  "bg-[#1e6fa8]",
];

export default function Reviews() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const carouselRef = useRef<HTMLDivElement>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [visibleCount, setVisibleCount] = useState(3);

  useEffect(() => {
    const updateVisible = () => {
      if (window.innerWidth < 768) setVisibleCount(1);
      else if (window.innerWidth < 1024) setVisibleCount(2);
      else setVisibleCount(3);
    };
    updateVisible();
    window.addEventListener("resize", updateVisible);
    return () => window.removeEventListener("resize", updateVisible);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll(".reveal").forEach((el, i) => {
              setTimeout(() => el.classList.add("visible"), i * 100);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const maxIndex = reviews.length - visibleCount;

  const prev = () => setCurrentIndex((i) => Math.max(0, i - 1));
  const next = () => setCurrentIndex((i) => Math.min(maxIndex, i + 1));

  return (
    <section id="reviews" className="py-24 bg-[#0d2137]" ref={sectionRef}>
      <div className="container">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-12">
          <div>
            <div className="reveal inline-flex items-center gap-3 mb-4">
              <div className="h-px w-10 bg-[#2d7a3a]" />
              <span className="text-[#4ade80] text-sm font-semibold tracking-wider uppercase">
                Customer Reviews
              </span>
            </div>
            <h2
              className="reveal text-4xl lg:text-5xl font-extrabold text-white leading-tight"
              style={{ fontFamily: "'Sora', sans-serif" }}
            >
              What Our Clients Say
            </h2>
          </div>

          {/* Overall rating */}
          <div className="reveal flex items-center gap-4 bg-[#142a3d] rounded-2xl px-6 py-4 border border-white/10">
            <div className="text-center">
              <div
                className="text-4xl font-extrabold text-white"
                style={{ fontFamily: "'Sora', sans-serif" }}
              >
                4.9
              </div>
              <div className="flex gap-0.5 mt-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <div className="text-xs text-slate-400 mt-1">Google Rating</div>
            </div>
            <div className="w-px h-12 bg-white/10" />
            <div className="text-center">
              <div
                className="text-4xl font-extrabold text-white"
                style={{ fontFamily: "'Sora', sans-serif" }}
              >
                200+
              </div>
              <div className="text-xs text-slate-400 mt-1">Reviews</div>
            </div>
          </div>
        </div>

        {/* Carousel */}
        <div className="overflow-hidden" ref={carouselRef}>
          <div
            className="flex gap-5 transition-transform duration-500 ease-in-out"
            style={{
              transform: `translateX(calc(-${currentIndex} * (100% / ${visibleCount} + 20px / ${visibleCount})))`,
            }}
          >
            {reviews.map((review, i) => (
              <div
                key={review.name}
                className="shrink-0 bg-[#142a3d] rounded-2xl p-6 border border-white/8 hover:border-white/15 transition-colors"
                style={{ width: `calc(${100 / visibleCount}% - ${(visibleCount - 1) * 20 / visibleCount}px)` }}
              >
                {/* Quote icon */}
                <Quote className="w-8 h-8 text-[#2d7a3a]/60 mb-4" />

                {/* Stars */}
                <div className="flex gap-0.5 mb-3">
                  {[...Array(review.rating)].map((_, j) => (
                    <Star key={j} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>

                {/* Text */}
                <p className="text-slate-300 text-sm leading-relaxed mb-5 line-clamp-4">
                  "{review.text}"
                </p>

                {/* Service tag */}
                <div className="inline-block px-2.5 py-1 rounded-full bg-[#2d7a3a]/20 text-[#4ade80] text-xs font-medium mb-4">
                  {review.service}
                </div>

                {/* Author */}
                <div className="flex items-center gap-3 pt-4 border-t border-white/8">
                  <div
                    className={`w-9 h-9 rounded-full ${avatarColors[i % avatarColors.length]} flex items-center justify-center text-white text-xs font-bold shrink-0`}
                  >
                    {review.avatar}
                  </div>
                  <div>
                    <div className="text-white text-sm font-semibold">{review.name}</div>
                    <div className="text-slate-500 text-xs">
                      {review.location} · {review.date}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between mt-8">
          <div className="flex gap-2">
            {Array.from({ length: maxIndex + 1 }).map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentIndex(i)}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  i === currentIndex ? "w-8 bg-[#2d7a3a]" : "w-1.5 bg-white/20"
                }`}
              />
            ))}
          </div>
          <div className="flex gap-2">
            <button
              onClick={prev}
              disabled={currentIndex === 0}
              className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-white hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={next}
              disabled={currentIndex >= maxIndex}
              className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-white hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
