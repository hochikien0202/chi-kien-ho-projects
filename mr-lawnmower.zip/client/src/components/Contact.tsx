/* =============================================================
   Contact — Corporate Precision design
   Navy background, two-column: form left, contact info right
   Form with service selector, validation feedback
   ============================================================= */

import { useEffect, useRef, useState } from "react";
import { Phone, Mail, MapPin, Clock, Send, CheckCircle2 } from "lucide-react";

const services = [
  "Landscape Maintenance",
  "Snow & Ice Management",
  "Irrigation Systems",
  "Seasonal Cleanup",
  "Landscape Design",
  "Other / Not Sure",
];

export default function Contact() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: "",
  });

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll(".reveal").forEach((el, i) => {
              setTimeout(() => el.classList.add("visible"), i * 100);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <section
      id="contact"
      className="py-24 bg-[#0d2137]"
      ref={sectionRef}
    >
      <div className="container">
        {/* Header */}
        <div className="text-center mb-14">
          <div className="reveal inline-flex items-center gap-3 mb-4">
            <div className="h-px w-10 bg-[#2d7a3a]" />
            <span className="text-[#4ade80] text-sm font-semibold tracking-wider uppercase">
              Get in Touch
            </span>
            <div className="h-px w-10 bg-[#2d7a3a]" />
          </div>
          <h2
            className="reveal text-4xl lg:text-5xl font-extrabold text-white leading-tight mb-4"
            style={{ fontFamily: "'Sora', sans-serif" }}
          >
            Request Your Free Quote
          </h2>
          <p className="reveal text-slate-400 text-lg max-w-xl mx-auto">
            Fill out the form and we'll get back to you within 24 hours with a
            detailed, no-obligation estimate.
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-8">
          {/* Form */}
          <div className="reveal lg:col-span-3 bg-[#142a3d] rounded-2xl p-8 border border-white/8">
            {submitted ? (
              <div className="flex flex-col items-center justify-center h-full py-16 text-center">
                <div className="w-16 h-16 rounded-full bg-[#2d7a3a]/20 flex items-center justify-center mb-4">
                  <CheckCircle2 className="w-8 h-8 text-[#4ade80]" />
                </div>
                <h3
                  className="text-2xl font-bold text-white mb-2"
                  style={{ fontFamily: "'Sora', sans-serif" }}
                >
                  Quote Request Sent!
                </h3>
                <p className="text-slate-400 max-w-sm">
                  Thank you, {form.name}! We'll review your request and contact
                  you within 24 hours with a personalized quote.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-6 px-5 py-2.5 rounded-lg bg-[#2d7a3a] text-white font-semibold text-sm hover:bg-[#3a9448] transition-colors"
                >
                  Submit Another Request
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1.5">
                      Full Name <span className="text-[#4ade80]">*</span>
                    </label>
                    <input
                      type="text"
                      name="name"
                      required
                      value={form.name}
                      onChange={handleChange}
                      placeholder="John Smith"
                      className="w-full px-4 py-3 rounded-lg bg-[#0d2137] border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:border-[#2d7a3a] focus:ring-1 focus:ring-[#2d7a3a] transition-colors text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1.5">
                      Email Address <span className="text-[#4ade80]">*</span>
                    </label>
                    <input
                      type="email"
                      name="email"
                      required
                      value={form.email}
                      onChange={handleChange}
                      placeholder="john@example.com"
                      className="w-full px-4 py-3 rounded-lg bg-[#0d2137] border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:border-[#2d7a3a] focus:ring-1 focus:ring-[#2d7a3a] transition-colors text-sm"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1.5">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={form.phone}
                      onChange={handleChange}
                      placeholder="(416) 555-0123"
                      className="w-full px-4 py-3 rounded-lg bg-[#0d2137] border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:border-[#2d7a3a] focus:ring-1 focus:ring-[#2d7a3a] transition-colors text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1.5">
                      Service Needed <span className="text-[#4ade80]">*</span>
                    </label>
                    <select
                      name="service"
                      required
                      value={form.service}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg bg-[#0d2137] border border-white/10 text-white focus:outline-none focus:border-[#2d7a3a] focus:ring-1 focus:ring-[#2d7a3a] transition-colors text-sm appearance-none"
                    >
                      <option value="" disabled>Select a service…</option>
                      {services.map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1.5">
                    Tell Us About Your Project
                  </label>
                  <textarea
                    name="message"
                    rows={4}
                    value={form.message}
                    onChange={handleChange}
                    placeholder="Describe your property, what you need, and any specific requirements…"
                    className="w-full px-4 py-3 rounded-lg bg-[#0d2137] border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:border-[#2d7a3a] focus:ring-1 focus:ring-[#2d7a3a] transition-colors text-sm resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 px-6 py-4 rounded-lg bg-[#2d7a3a] hover:bg-[#3a9448] text-white font-bold text-base transition-all duration-200 hover:shadow-lg hover:shadow-green-900/30 active:scale-[0.98]"
                  style={{ fontFamily: "'Sora', sans-serif" }}
                >
                  <Send className="w-4 h-4" />
                  Send My Quote Request
                </button>

                <p className="text-center text-xs text-slate-500">
                  We respond within 24 hours. No spam, no commitment required.
                </p>
              </form>
            )}
          </div>

          {/* Contact info */}
          <div className="reveal reveal-delay-2 lg:col-span-2 flex flex-col gap-5">
            {/* Call CTA */}
            <a
              href="tel:+14165550123"
              className="group flex items-center gap-4 p-5 rounded-2xl bg-[#2d7a3a] hover:bg-[#3a9448] transition-colors"
            >
              <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="text-white/70 text-xs font-medium uppercase tracking-wider mb-0.5">
                  Call Us Now
                </div>
                <div
                  className="text-white text-xl font-bold"
                  style={{ fontFamily: "'Sora', sans-serif" }}
                >
                  (416) 555-0123
                </div>
              </div>
            </a>

            {/* Info cards */}
            <div className="bg-[#142a3d] rounded-2xl p-6 border border-white/8 space-y-5">
              <div className="flex items-start gap-4">
                <div className="w-9 h-9 rounded-lg bg-[#1e6fa8]/20 flex items-center justify-center shrink-0 mt-0.5">
                  <Mail className="w-4 h-4 text-[#7eb8d4]" />
                </div>
                <div>
                  <div className="text-slate-400 text-xs font-medium uppercase tracking-wider mb-0.5">Email</div>
                  <a href="mailto:info@mrlawnmower.ca" className="text-white text-sm font-medium hover:text-[#4ade80] transition-colors">
                    info@mrlawnmower.ca
                  </a>
                </div>
              </div>

              <div className="h-px bg-white/8" />

              <div className="flex items-start gap-4">
                <div className="w-9 h-9 rounded-lg bg-[#2d7a3a]/20 flex items-center justify-center shrink-0 mt-0.5">
                  <MapPin className="w-4 h-4 text-[#4ade80]" />
                </div>
                <div>
                  <div className="text-slate-400 text-xs font-medium uppercase tracking-wider mb-0.5">Service Area</div>
                  <div className="text-white text-sm font-medium">Toronto & Greater Toronto Area</div>
                  <div className="text-slate-400 text-xs mt-0.5">North York · Scarborough · Etobicoke · Mississauga · Markham · Richmond Hill</div>
                </div>
              </div>

              <div className="h-px bg-white/8" />

              <div className="flex items-start gap-4">
                <div className="w-9 h-9 rounded-lg bg-[#1e6fa8]/20 flex items-center justify-center shrink-0 mt-0.5">
                  <Clock className="w-4 h-4 text-[#7eb8d4]" />
                </div>
                <div>
                  <div className="text-slate-400 text-xs font-medium uppercase tracking-wider mb-0.5">Hours</div>
                  <div className="text-white text-sm font-medium">Mon – Fri: 7:00 AM – 6:00 PM</div>
                  <div className="text-slate-400 text-xs mt-0.5">Sat: 8:00 AM – 4:00 PM</div>
                  <div className="text-[#4ade80] text-xs mt-1 font-medium">24/7 Snow Emergency Line</div>
                </div>
              </div>
            </div>

            {/* Response time badge */}
            <div className="bg-[#142a3d] rounded-2xl p-5 border border-[#2d7a3a]/30">
              <div className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 rounded-full bg-[#4ade80] animate-pulse" />
                <div>
                  <div className="text-white font-semibold text-sm">Typical Response Time</div>
                  <div className="text-[#4ade80] font-bold text-lg" style={{ fontFamily: "'Sora', sans-serif" }}>
                    Under 2 Hours
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
